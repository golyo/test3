'use strict';

angular.module('myApp.view1', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/login', {
    templateUrl: 'login/login.html',
    controller: 'View1Ctrl',
    resolve: {
        data: function(AuthFactory) {
                        var data = AuthFactory.getData();
                        // This block needs to be run after my $http call in 'run' has been resolved.
                        return data;
         }
    }
  });
}])

.controller('View1Ctrl', function($scope, $rootScope, $location) {
    console.log("View1Ctrl " + $rootScope.user);
    if ($rootScope.user) {
        $location.path( "/view2" );
    }
    $scope.test = function() {
        console.log("test");
    };
});